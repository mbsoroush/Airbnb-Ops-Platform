-- Table and column inspection of the core schema, for the build report.
SELECT table_name, column_name, data_type
FROM information_schema.columns
WHERE table_schema = 'core'
ORDER BY table_name, ordinal_position;
